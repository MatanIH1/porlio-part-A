# GitHub Portfolio (English)
A ready-to-use portfolio page built with HTML/CSS/JS that fetches and displays your public GitHub repositories.

## Folder Structure
```
github-portfolio-en/
├─ index.html
├─ styles/styles.css
├─ scripts/script.js
└─ assets/avatar-placeholder.svg
```

## Usage
1. Open the folder `github-portfolio-en` in VS Code.
2. In `index.html`, change the username field value to your GitHub username (or enter it in the input field in the browser).
3. Open the file with Live Server (if installed) or run a local server:
   - Python 3: `python -m http.server 8000`
   - Node (serve): `npx serve`
4. Click **Load Projects**.

## Features
- Dark/Light mode toggle.
- Responsive layout.
- Search, filter, and sort repositories.
- Hover effects on cards.

## Notes
- No token required. If you hit rate-limit, refresh after a few minutes or add Authorization with a personal token for testing.
